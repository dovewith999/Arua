// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "DataTables/ARWeaponData.h"
#include "NativeGameplayTags.h"
#include "ARWeaponBase.generated.h"


UCLASS()
class ARUA_API AARWeaponBase : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AARWeaponBase();

	// ���⸦ �����ϴ� �Լ�
	virtual void AttachToSocket(class ACharacter* Character, FName SocketName);
	// ���⸦ �����ϴ� �Լ�
	virtual void DetachFromCharacter();

	virtual void InitializeFromData();

	//FORCEINLINE EWeaponType GetWeaponType() { return WeaponType; } 

protected:
	virtual void BeginPlay() override;

public:
	UPROPERTY(EditAnywhere,BlueprintReadOnly, Category = Weapon)
	TObjectPtr<class UDataTable> WeaponDataTable;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Weapon)
	FName WeaponName;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Weapon)
	FARWeaponData WeaponData;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Weapon)
	TObjectPtr<class UStaticMeshComponent> WeaponStaticMesh;

	// ���� Ÿ��
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Weapon)
	FGameplayTag WeaponTag;

	// ���� ���� ��Ÿ��
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Animation)
	TObjectPtr<class UAnimMontage> WeaponEquipMontage;

	// ���⿡ ���� AnimBp
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Animation)
	TObjectPtr<class UAnimInstance> AnimInstanceByWeapon;
	
};
